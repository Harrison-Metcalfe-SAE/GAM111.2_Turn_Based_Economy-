﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class TurnController : MonoBehaviour {

    public EventSystem LevelEventSystem;

    // Use this for initialization
    void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {

        // Check for user click
        if (Input.GetMouseButtonDown(0))
        {
            // Setup the ray based on mouse locale
            Ray mousePos = Camera.main.ScreenPointToRay(Input.mousePosition);

            // Perform raycast to determine click
            RaycastHit hitResults;
            if (Physics.Raycast(mousePos, out hitResults))
            {
                // retrieve the game object that hit
                GameObject hitObject = hitResults.collider.gameObject;

                if (hitObject.tag == "Tile")
                {
                    Debug.Log("It works");
                }
            }
        }
    }
}